# Python Programs Website

A simple file-browser style website for downloading Python programs.

## Run locally
Open `index.html` in a browser.

## Deploy to Vercel
Upload this folder to a GitHub repository and import it into Vercel.
No build command is required.

## Programs
The `programs` folder contains the individual `.py` files.
