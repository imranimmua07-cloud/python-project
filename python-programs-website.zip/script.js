const programs = [
  ["1. Numeric Data Types & Arithmetic", "01_numeric_data_types.py"],
  ["2. List and Tuple", "02_list_and_tuple.py"],
  ["3. Dictionary", "03_dictionary.py"],
  ["4. NumPy Array and Indexing", "04_numpy_array_and_indexing.py"],
  ["5. Summary Statistics", "05_summary_statistics.py"],
  ["6. Geographical Data using Basemap", "06_geographical_data_basemap.py"],
  ["7. Bar Chart", "07_bar_chart.py"],
  ["8. Using Module - mymath.py", "08_using_module_mymath.py"],
  ["8. Using Module - main.py", "08_using_module_main.py"],
  ["9. File Handling", "09_file_handling.py"],
  ["10. Control Structures", "10_control_structures.py"]
];

const list = document.getElementById("programList");
const empty = document.getElementById("empty");
const search = document.getElementById("searchInput");

function render(items = programs) {
  list.innerHTML = "";
  empty.hidden = items.length !== 0;

  items.forEach(([title, file]) => {
    const card = document.createElement("article");
    card.className = "file-card";
    card.innerHTML = `
      <div class="file-info">
        <div class="file-icon">🐍</div>
        <div>
          <div class="file-title">${title}</div>
          <div class="file-name">${file}</div>
        </div>
      </div>
      <button class="download" data-file="${file}">↓ Download</button>
    `;
    list.appendChild(card);
  });

  document.querySelectorAll(".download").forEach(btn => {
    btn.addEventListener("click", () => {
      const a = document.createElement("a");
      a.href = "programs/" + encodeURIComponent(btn.dataset.file);
      a.download = btn.dataset.file;
      document.body.appendChild(a);
      a.click();
      a.remove();
    });
  });
}

search.addEventListener("input", () => {
  const q = search.value.trim().toLowerCase();
  render(programs.filter(([title, file]) =>
    title.toLowerCase().includes(q) || file.toLowerCase().includes(q)
  ));
});

document.getElementById("gridBtn").addEventListener("click", () => {
  list.classList.remove("list");
  document.getElementById("gridBtn").classList.add("active");
  document.getElementById("listBtn").classList.remove("active");
});

document.getElementById("listBtn").addEventListener("click", () => {
  list.classList.add("list");
  document.getElementById("listBtn").classList.add("active");
  document.getElementById("gridBtn").classList.remove("active");
});

document.getElementById("backBtn").onclick = () => history.back();
document.getElementById("forwardBtn").onclick = () => history.forward();

render();
