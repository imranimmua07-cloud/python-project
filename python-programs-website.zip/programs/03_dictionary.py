# 3. Dictionary

d = {
    "name": "Ahamed",
    "age": 25
}

print(d["name"])
print(d["age"])

d["grade"] = "A"
d["age"] = 26

print("Updated:", d)
print(d.keys())
print(d.values())
