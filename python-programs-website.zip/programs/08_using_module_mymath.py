# 8. Using Module - mymath.py
# This file is the module used by main.py.

def add(a, b):
    return a + b

def sub(a, b):
    return a - b

def mul(a, b):
    return a * b

def div(a, b):
    return a / b
