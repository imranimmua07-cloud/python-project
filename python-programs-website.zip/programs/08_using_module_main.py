# 8. Using Module - main.py
# Keep this file in the same folder as mymath.py.

import mymath

a = 10
b = 5

print("Addition:", mymath.add(a, b))
print("Subtraction:", mymath.sub(a, b))
print("Multiplication:", mymath.mul(a, b))
print("Division:", mymath.div(a, b))
