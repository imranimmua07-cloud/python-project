# 5. Summary Statistics

import statistics

data = [10, 20, 20, 30, 40, 40, 40, 50, 60]

print("Mean:", statistics.mean(data))
print("Median:", statistics.median(data))
print("Mode:", statistics.mode(data))
print("Standard Deviation:", statistics.stdev(data))
print("Variance:", statistics.variance(data))
