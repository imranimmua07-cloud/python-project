# 4. NumPy Array and Indexing

import numpy as np

a = np.array([10, 20, 30, 40, 50])

print("Array:", a)
print("Slice:", a[1:4])
print("First 3:", a[:3])
print("Every 2nd:", a[::2])
print("Add 10:", a + 10)
print("Multiply 2:", a * 2)

print("Sum:", a.sum())
print("Maximum:", a.max())
print("Mean:", a.mean())
