# 1. Numeric Data Types & Arithmetic

a = 10
b = 3.5
c = 2 + 3j

print("a =", a, type(a))
print("b =", b, type(b))
print("c =", c, type(c))

print("Addition:", a + b)
print("Subtraction:", a - b)
print("Multiplication:", a * b)
print("Division:", a / b)
print("Modulus:", a % 3)
print("Floor Division:", a // b)
print("Power:", a ** 2)
