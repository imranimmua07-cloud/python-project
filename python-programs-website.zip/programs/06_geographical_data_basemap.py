# 6. Geographical Data using Basemap

from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt

m = Basemap(projection='cyl')

m.drawmapboundary(fill_color='aqua')
m.fillcontinents(color='coral')
m.drawcoastlines()

plt.show()
