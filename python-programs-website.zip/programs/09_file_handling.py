# 9. File Handling

with open("example.txt", "w") as f:
    f.write("Hello Python\n")
    f.write("File handling")

print("Data written successfully")

with open("example.txt", "r") as f:
    print(f.read())
