# 10. Control Structures

# If
n = 10

if n > 0:
    print("Positive")
else:
    print("Negative")

# For loop
for i in range(1, 6):
    print(i, end=" ")

# While loop
print()
i = 5

while i > 0:
    print(i, end=" ")
    i -= 1

# Break
print()
for i in range(1, 10):
    if i == 5:
        break
    print(i, end=" ")
