# 2. List and Tuple

a = [10, 20, 30]

a.append(40)
print("Append:", a)

a.insert(1, 15)
print("Insert:", a)

a.remove(20)
print("Remove:", a)

a.reverse()
print("Reverse:", a)

t = ("sun", "wed", "fri")
print("Tuple:", t)
print("First:", t[0])
print("Slice:", t[1:3])
print("Length:", len(t))
